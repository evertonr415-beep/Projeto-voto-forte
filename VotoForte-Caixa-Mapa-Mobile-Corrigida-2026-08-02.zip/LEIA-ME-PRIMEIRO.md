# Backup completo — VOTO FORTE PARANÁ

Data do pacote: 01/08/2026 (America/Sao_Paulo)

Este pacote contém o código-fonte da versão mais recente disponível no projeto, incluindo as alterações de endereço/CEP e confirmação do pino no mapa, telas, imagens, autenticação, agenda, banco de dados, testes e configurações de publicação.

## Restauração rápida

1. Extraia o ZIP preservando as pastas.
2. Entre na pasta `projeto`.
3. Instale Node.js 20 ou superior.
4. Execute `npm ci`.
5. Configure as variáveis descritas em `VARIAVEIS-DE-AMBIENTE.example`.
6. Execute `npm run build` para validar.
7. Para desenvolvimento, execute `npm run dev`.

## Publicação

O arquivo `.vercel/project.json` identifica o projeto Vercel usado nesta versão. O domínio público informado no projeto é `www.sistemavotoforte.com.br`; o endereço padrão é `https://voto-forte-parana.vercel.app`.

Nunca envie chaves ou senhas para um repositório público. As credenciais reais não estão neste backup e devem ser cadastradas novamente no painel seguro da hospedagem.

## Conferência de integridade

O arquivo `SHA256SUMS.txt` contém o hash de cada arquivo. Em Linux/macOS, execute na raiz extraída:

```bash
sha256sum -c SHA256SUMS.txt
```

O arquivo `INVENTARIO-ARQUIVOS.txt` registra a lista do código incluído. `COMMIT-BASE.txt` registra o commit-base e `ALTERACOES-NAO-COMMITADAS.patch` preserva também as diferenças mais recentes em formato reutilizável.

## Itens propositalmente excluídos

- `node_modules` (reinstalado por `npm ci`)
- caches e artefatos de compilação (`.next`, `.vinext`, `dist`, `build`)
- histórico Git completo
- arquivos `.env`, tokens, senhas e credenciais

